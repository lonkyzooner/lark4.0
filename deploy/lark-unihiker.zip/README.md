# LARK for UniHiker M10

## Deployment Instructions

1. Extract this ZIP file to a directory on your computer
2. Connect to your UniHiker M10 via SSH or USB
3. Copy the extracted files to the UniHiker's web server directory
4. Access the application via the UniHiker's web browser

## Features

- Voice-activated interface with "Hey LARK" wake word
- Miranda rights reading in multiple languages
- Louisiana statute lookups
- Audio-based threat detection
- Tactical feedback

## Troubleshooting

If you encounter any issues:
- Check that the UniHiker has internet connectivity
- Ensure the device has sufficient storage space
- Verify that the web server is running correctly

For additional support, please contact the development team.
