#!/bin/bash
# LARK UniHiker Startup Script

# Set the web server directory
WEB_DIR="/var/www/html"

# Copy LARK files to web server directory
echo "Copying LARK files to web server..."
cp -r ./* $WEB_DIR/

# Set appropriate permissions
chmod -R 755 $WEB_DIR

# Start the web server if not already running
if ! systemctl is-active --quiet nginx; then
  echo "Starting web server..."
  systemctl start nginx
fi

echo "LARK is now available at http://localhost"
echo "You can access it from the UniHiker's web browser"
